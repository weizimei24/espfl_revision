"""
train_utils.py
==============
训练相关的实用函数和类。

    函数：
        count_parameters          —— 统计可训练参数量
        test_model                —— 评估模型准确率
        train_epoch               —— 普通单 epoch 训练
        train_epoch_with_distillation —— 知识蒸馏单 epoch 训练
        recalibrate_bn            —— 重校准 BatchNorm 统计量

    类：
        AdaptiveKnowledgeDistillationLoss —— 自适应 KD 损失
        PerformanceMonitor                —— 客户端性能监控器

设计原则：
    - 本文件不依赖任何项目内的其他模块（models/aggregation/data_fed 等）
    - 所有函数均通过参数接收 device，不使用全局 device 变量
    - 删除已被 data_fed.py 替代的 get_cifar10_loaders()
"""

from __future__ import annotations
from pyexpat import model

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from typing import Optional, Tuple, Union


# ─────────────────────────────────────────────────────────────────────────────
# 参数统计
# ─────────────────────────────────────────────────────────────────────────────

def count_parameters(model: nn.Module) -> int:
    """统计模型可训练参数总量。"""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


# ─────────────────────────────────────────────────────────────────────────────
# 模型评估
# ─────────────────────────────────────────────────────────────────────────────

def test_model(model, testloader, device, return_loss=False):
    """
    在 testloader 上评估模型准确率。

    返回：
        accuracy: float，百分比形式（如 83.24）
    """
    model.eval()
    correct = 0
    total   = 0
    total_loss = 0.0
    criterion = nn.CrossEntropyLoss(reduction='sum')

    with torch.no_grad():
        for inputs, targets in testloader:
            inputs  = inputs.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)
            outputs = model(inputs)
            _, predicted = outputs.max(1)
            total      += targets.size(0)
            correct    += predicted.eq(targets).sum().item()
            if return_loss:
                total_loss += criterion(outputs, targets).item()

    accuracy = 100.0 * correct / total
    if return_loss:
        return accuracy, total_loss / total
    return accuracy


# def test_model(
#     model: nn.Module,
#     testloader: DataLoader,
#     device: torch.device,
#     return_loss: bool = False,
#     verbose: bool = False,
# ) -> Union[float, Tuple[float, float]]:
#     """
#     在 testloader 上评估模型准确率（及可选的平均 loss）。

#     参数：
#         model       : 待评估模型
#         testloader  : 测试数据加载器
#         device      : 推理设备
#         return_loss : 若为 True，同时返回平均 loss
#         verbose     : 若为 True，打印详细结果

#     返回：
#         accuracy              : float，百分比形式（如 83.24）
#         (accuracy, avg_loss)  : 若 return_loss=True
#     """
#     model.eval()

#     test_loss = torch.zeros(1, device=device)
#     correct   = torch.zeros(1, device=device, dtype=torch.long)
#     total     = 0

#     with torch.no_grad():
#         for inputs, targets in testloader:
#             # ── target 类型安全处理 ──────────────────────────────
#             if not torch.is_tensor(targets):
#                 targets = torch.tensor(targets)
#             if targets.dim() == 0:
#                 targets = targets.unsqueeze(0)
#             targets = targets.long()

#             inputs  = inputs.to(device,  non_blocking=True)
#             targets = targets.to(device, non_blocking=True)

#             outputs = model(inputs)

#             # ── 兼容 dict 输出（如某些模型返回 {'output': logits, ...}）──
#             if isinstance(outputs, dict):
#                 outputs = outputs['output']

#             test_loss += F.cross_entropy(outputs, targets, reduction='sum')

#             pred     = outputs.argmax(dim=1)
#             correct += pred.eq(targets).sum()
#             total   += targets.size(0)

#     avg_loss = (test_loss / total).item()
#     accuracy = (100.0 * correct / total).item()

#     if verbose:
#         print(
#             f'\nTest set: Average loss: {avg_loss:.4f} | '
#             f'Accuracy: {correct.item()}/{total} ({accuracy:.2f}%)\n'
#         )

#     if return_loss:
#         return accuracy, avg_loss
#     return accuracy

# ─────────────────────────────────────────────────────────────────────────────
# BatchNorm 重校准
# ─────────────────────────────────────────────────────────────────────────────

def recalibrate_bn(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    num_batches: int = 20,
) -> None:
    """
    用少量 batch 重新计算 BN 的 running_mean / running_var。

    适用场景：
        - 聚合后全局模型的 BN 统计量可能与当前数据分布不符
        - 剪枝后的个性化模型在首次推理前校准

    注意：此函数会短暂将模型置为 train() 模式，结束后恢复 eval()。
    """
    model.train()
    with torch.no_grad():
        for batch_idx, (x, _) in enumerate(loader):
            if batch_idx >= num_batches:
                break
            x = x.to(device, non_blocking=True)
            model(x)
    model.eval()


# ─────────────────────────────────────────────────────────────────────────────
# 普通训练
# ─────────────────────────────────────────────────────────────────────────────

def train_epoch(
    model: nn.Module,
    trainloader: DataLoader,
    optimizer: torch.optim.Optimizer,
    criterion: nn.Module,
    device: torch.device,
    tracker=None,
) -> Tuple[float, float]:
    """
    普通单 epoch 训练（无蒸馏）。

    参数：
        model       : 待训练模型
        trainloader : 训练数据加载器
        optimizer   : 优化器
        criterion   : 损失函数（通常为 CrossEntropyLoss）
        device      : 训练设备
        tracker     : EvolutionTracker 实例，可为 None

    返回：
        avg_loss  : float，该 epoch 平均 loss
        accuracy  : float，该 epoch 训练准确率（百分比）
    """
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    for inputs, targets in trainloader:
        inputs  = inputs.to(device,  non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        if tracker is not None:
            tracker.update(loss)

        running_loss += loss.item()
        _, predicted  = outputs.max(1)
        total        += targets.size(0)
        correct      += predicted.eq(targets).sum().item()

    avg_loss = running_loss / len(trainloader)
    accuracy = 100.0 * correct / total
    return avg_loss, accuracy


# ─────────────────────────────────────────────────────────────────────────────
# 知识蒸馏训练
# ─────────────────────────────────────────────────────────────────────────────

def train_epoch_with_distillation(
    student_model: nn.Module,
    teacher_model: nn.Module,
    trainloader: DataLoader,
    optimizer: torch.optim.Optimizer,
    distill_criterion: "AdaptiveKnowledgeDistillationLoss",
    device: torch.device,
    tracker=None,
    grad_clip: float = 0.5,
) -> Tuple[float, float, float, float]:
    """
    知识蒸馏单 epoch 训练。

    参数：
        student_model    : 学生模型（被训练）
        teacher_model    : 教师模型（推理用，不更新梯度）
        trainloader      : 训练数据加载器
        optimizer        : 学生模型的优化器
        distill_criterion: AdaptiveKnowledgeDistillationLoss 实例
        device           : 训练设备
        tracker          : EvolutionTracker 实例，可为 None
        grad_clip        : 梯度裁剪阈值，默认 0.5

    返回：
        avg_loss      : float，总 loss 均值
        accuracy      : float，训练准确率（百分比）
        avg_hard_loss : float，硬标签（CE）loss 均值
        avg_soft_loss : float，软标签（KD）loss 均值
    """
    student_model.train()
    teacher_model.eval()

    running_loss       = 0.0
    running_hard_loss  = 0.0
    running_soft_loss  = 0.0
    running_feat_loss  = 0.0
    correct = 0
    total   = 0

    for inputs, targets in trainloader:
        inputs  = inputs.to(device,  non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        optimizer.zero_grad()

        student_outputs = student_model(inputs)

        with torch.no_grad():
            teacher_outputs = teacher_model(inputs)

        total_loss, hard_loss, soft_loss, feature_loss = distill_criterion(
            student_outputs, teacher_outputs, targets
        )

        total_loss.backward()

        if grad_clip > 0:
            torch.nn.utils.clip_grad_norm_(student_model.parameters(), max_norm=grad_clip)

        optimizer.step()

        if tracker is not None:
            tracker.update(total_loss)

        running_loss      += total_loss.item()
        running_hard_loss += hard_loss.item()
        running_soft_loss += soft_loss.item()
        running_feat_loss += (
            feature_loss if isinstance(feature_loss, (int, float))
            else feature_loss.item()
        )

        _, predicted = student_outputs.max(1)
        total   += targets.size(0)
        correct += predicted.eq(targets).sum().item()

    n = len(trainloader)
    avg_loss      = running_loss      / n
    accuracy      = 100.0 * correct  / total
    avg_hard_loss = running_hard_loss / n
    avg_soft_loss = running_soft_loss / n

    return avg_loss, accuracy, avg_hard_loss, avg_soft_loss


# ─────────────────────────────────────────────────────────────────────────────
# 自适应知识蒸馏损失
# ─────────────────────────────────────────────────────────────────────────────

class AdaptiveKnowledgeDistillationLoss:
    """
    自适应知识蒸馏损失函数。

    损失 = (1 - alpha) * CE(student, labels)
          + alpha      * KL(student_soft || teacher_soft) * T²

    alpha 和 temperature 会根据 update_iteration() 传入的性能比例动态调整：
        - 性能良好（ratio ≥ 0.95）：使用初始参数
        - 性能轻微下降（0.85 ≤ ratio < 0.95）：提高 T，平衡软硬标签
        - 性能大幅下降（ratio < 0.85）：降低 alpha，主要依赖硬标签

    可选的特征蒸馏（传入 student_features / teacher_features）：
        额外加入 0.1 * MSE(student_feat, teacher_feat)
        维度不匹配时自动用自适应池化 + 1×1 conv 对齐。
    """

    def __init__(self, temperature: float = 3.0, alpha: float = 0.5):
        self.initial_temperature = temperature
        self.initial_alpha       = alpha
        self.temperature         = temperature
        self.alpha               = alpha

        self.ce_loss  = nn.CrossEntropyLoss()
        self.kd_loss  = nn.KLDivLoss(reduction='batchmean')
        self.mse_loss = nn.MSELoss()
        self.iteration = 0

    def update_iteration(
        self,
        iteration: int,
        performance_ratio: float = 1.0,
    ) -> None:
        """
        根据当前轮次和性能比例动态调整蒸馏超参数。

        参数：
            iteration        : 当前训练轮次（用于记录，当前未参与计算）
            performance_ratio: student_acc / teacher_acc，越接近 1 越好
        """
        self.iteration = iteration

        if performance_ratio < 0.85:
            # 性能大幅下降：主要依赖硬标签，减小软标签权重
            self.alpha       = 0.1
            self.temperature = 2.0
        elif performance_ratio < 0.95:
            # 性能轻微下降：提高温度，平衡软硬标签
            self.alpha       = 0.3
            self.temperature = min(4.0, self.initial_temperature + 0.5)
        else:
            # 性能良好：恢复初始参数
            self.alpha       = self.initial_alpha
            self.temperature = self.initial_temperature

    def __call__(
        self,
        student_outputs: torch.Tensor,
        teacher_outputs: torch.Tensor,
        targets: torch.Tensor,
        student_features: Optional[torch.Tensor] = None,
        teacher_features: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, Union[torch.Tensor, float]]:
        """
        计算蒸馏损失。

        返回：
            total_loss   : 总损失（用于 backward）
            hard_loss    : CE 损失
            soft_loss    : KL 蒸馏损失
            feature_loss : 特征蒸馏损失（未使用特征时为 0.0）
        """
        # 硬标签损失
        hard_loss = self.ce_loss(student_outputs, targets)

        # 软标签（KD）损失
        student_soft = F.log_softmax(student_outputs / self.temperature, dim=1)
        teacher_soft = F.softmax(teacher_outputs   / self.temperature, dim=1)
        soft_loss    = self.kd_loss(student_soft, teacher_soft) * (self.temperature ** 2)

        total_loss = (1 - self.alpha) * hard_loss + self.alpha * soft_loss

        # 可选特征蒸馏
        feature_loss: Union[torch.Tensor, float] = 0.0
        if student_features is not None and teacher_features is not None:
            if student_features.shape != teacher_features.shape:
                # 空间尺寸不匹配：自适应池化对齐
                teacher_features = F.adaptive_avg_pool2d(
                    teacher_features, student_features.shape[-2:]
                )
                # 通道数不匹配：1×1 conv 对齐
                if teacher_features.shape[1] != student_features.shape[1]:
                    adapter = nn.Conv2d(
                        teacher_features.shape[1],
                        student_features.shape[1],
                        kernel_size=1,
                    ).to(student_features.device)
                    teacher_features = adapter(teacher_features)

            feature_loss = self.mse_loss(student_features, teacher_features.detach())
            total_loss   = total_loss + 0.1 * feature_loss

        return total_loss, hard_loss, soft_loss, feature_loss


# ─────────────────────────────────────────────────────────────────────────────
# 客户端性能监控器
# ─────────────────────────────────────────────────────────────────────────────

class PerformanceMonitor:
    """
    客户端本地性能监控器，用于驱动渐进式个性化的停止/继续决策。

    主要职责：
        - 记录历史准确率
        - 判断性能是否停滞（patience 机制）
        - 判断是否应停止压缩（should_stop_compression，由 OurMethod 调用）

    注意：should_stop_compression 中的绝对阈值（85%）是针对 CIFAR-10 的经验值。
    OurMethod 在调用前会根据 dataset_name 自行决定是否使用此方法，
    或直接用内联逻辑替代，此处保留原始实现供参考。
    """

    def __init__(self, patience: int = 2, min_improvement: float = 0.01):
        self.patience          = patience
        self.min_improvement   = min_improvement
        self.best_acc          = 0.0
        self.no_improvement_count = 0
        self.performance_history: list = []
        self.initial_acc: Optional[float] = None

    def set_initial_performance(self, initial_acc: float) -> None:
        """设置首次达到 observation_period 时的准确率作为基准。"""
        self.initial_acc = initial_acc
        self.best_acc    = initial_acc

    def update(self, accuracy: float) -> Tuple[bool, str]:
        """
        记录一次新的准确率，返回 (是否有改善, 描述信息)。

        返回：
            improved : bool
            message  : str
        """
        self.performance_history.append(accuracy)

        if accuracy > self.best_acc + self.min_improvement:
            self.best_acc             = accuracy
            self.no_improvement_count = 0
            return True, "Performance improved"
        else:
            self.no_improvement_count += 1
            if self.no_improvement_count >= self.patience:
                return False, "Performance stagnation detected"
            return True, f"No improvement for {self.no_improvement_count} iterations"

    def should_stop_compression(self, current_acc: float) -> Tuple[bool, str]:
        """
        判断是否应停止对该客户端的进一步压缩。
        基于三条规则（均可被 OurMethod 的内联逻辑覆盖）：
            1. 绝对性能低于 85%
            2. 相对初始性能下降超过 8%
            3. 近两次出现超过 5% 的单次下降
        """
        if current_acc < 85.0:
            return True, f"Absolute performance too low: {current_acc:.2f}%"

        if self.initial_acc is not None and current_acc < self.initial_acc * 0.92:
            return (
                True,
                f"Performance dropped too much from initial: "
                f"{current_acc:.2f}% vs {self.initial_acc:.2f}%",
            )

        if len(self.performance_history) >= 2:
            recent = self.performance_history[-2:]
            if recent[-1] < recent[0] * 0.95:
                return True, "Significant performance decline detected"

        return False, "Performance acceptable"