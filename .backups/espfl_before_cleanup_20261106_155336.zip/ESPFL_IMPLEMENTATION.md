# ESPFL 新实现说明（对应《方法架构·最终版》2026-11-06）

## 1. 文件与运行

| 文件 | 作用 |
|---|---|
| `slim_models.py` | 共享模板的**索引级子网**：通道组描述、任意通道子集的切片/回散、参数量计数、AKI 门控。state_dict 键名与 `models.build_model` 完全一致（有单测保证） |
| `espfl_easa.py` | EASA：S/E/D 轨迹统计（Eq.4–7）、组成决策（Eq.10–13）、容量控制器（§3.2，含消融与旧控制器） |
| `espfl_method.py` | 协议（延迟切换）、AKI 激活轮、SPPA / 填零聚合、结构日志 |
| `run_espfl.py` | 命令行入口，`--preset` 覆盖预实验与消融 |
| `scripts/preexp.sh` | 预实验一键脚本 |
| `tests/test_espfl.py` | 9 项正确性测试 |
| `data_fed.py`（修改） | train/val/test 三分 + 本地评估 transform 修复 |
| `main.py`（修改） | 新增 `METHOD='espfl'`；所有方法共用三分后的训练子集；结束时对全部 N 个客户端做最终 Local 评估 |

旧实现 `our_method.py`、`pruning.py`、`aggregation.py` 未改动（baseline 依赖 `aggregation.py`），仅作复现用。

```bash
python tests/test_espfl.py
python run_espfl.py --data_root DATA --dataset cifar10 --model vgg16 --alpha 0.3 --preset new
bash scripts/preexp.sh DATA cifar10 vgg16 0.3
```

## 2. 论文 ↔ 代码对应

| 论文 / 文档 | 代码 |
|---|---|
| Alg.1 第 9–13 行（存在待激活掩码 → AKI → 激活，重置 p_i 与轨迹） | `ESPFLMethod._activation_round` |
| Alg.1 第 15–16 行（常规训练 + S/E/D 统计，p_i+1） | `_regular_round` + `TrajectoryStats.begin/step/end` |
| Alg.1 第 17 行条件：p_i mod T_part=0、s_i<S_total、ρ>ρ_min | `_can_decide` + `_regular_round` |
| §3.2 水平门控 `eq:cap_permit` | `CapacityController.decide` 第 1 步 |
| §3.2 趋势力度 `eq:cap_intensity` | 第 2 步（`eta_up=None` 时与文档公式逐字一致） |
| §3.2 可行性 `eq:cap_feasible`（逐层下限、全局下限二分） | `_candidate` + 第 3 步 |
| §3.2 执行（δ_min 按参数量计；全局下限导致跳过则永久停止） | 第 4 步 |
| Eq.4 S/E/D，Eq.5 参与内平均，Eq.6 EMA，Eq.7 分位数归一化 | `TrajectoryStats`、`_qnorm` |
| Eq.10–13 候选池 + E(1−D) 排序 + Top-K；Eq.14 嵌套 | `compose_successor` |
| Eq.15–16 渐进门控 1−r/R | `set_gate`（门控乘在该通道组激活上） |
| Eq.17 Θ_T←本地旧模型，Θ_S←Θ_G | `_activation_round` |
| Eq.18–19 L_AKI，Eq.20 Δπ（**由实际掩码计算**），Eq.21 Δout，Eq.22 γ | 同上 |
| Eq.23–26 SPPA（仅按观测集 O_j 归一化，未观测坐标不变） | `CoverageAccumulator.apply(mode='sppa')` |
| "w/o SPPA" = 填零聚合 | `mode='zerofill'` |
| 数据三分 | `data_fed._three_way_split` |

## 3. 相对原实现修正的问题

1. **测试集参与决策**：原实现的停止条件、稀疏度、KD 参数都用 `test_loaders`。新实现中决策只读验证集；本地测试集只在评估（及每轮监控打印，不进入任何决策）中使用。
2. **本地测试集带训练增强**：原 `data_fed` 用 `DatasetSplit(dataset_train, test_idx)`，评估时有 RandomCrop+Flip。已改为无增强视图（`fix_eval_transform=True`），**影响所有方法的 Local 数字**。
3. **聚合坐标错误**：原 VGG 个性化模型经 SVD 扩展后按前缀上传，保留通道被放到错误的模板坐标；ResNet 把被剪坐标填旧全局值（等价填零）。新实现按绝对通道索引切片和回散，SPPA 只在实际上传坐标上归一化。
4. **协议**：补上 S_total 上限、延迟切换（生成→缓存→下次参与时激活）、渐进门控；通道评分改为论文的两步法（原实现是三项加权和 + 层位置权重 + 权重范数）。
5. **优化器**：默认与 baseline 代码一致（SGD，momentum 0.9，wd 1e-4，lr 由 trainer 给出 3e-4·0.998^t）。`--optimizer adamw` 可复现旧 ESPFL 设置，但那样与 baseline 不公平。

## 4. 实现选择（与论文字面不同或论文未规定之处）

| 选择 | 原因 |
|---|---|
| S 取 \|Σ g·W\|（论文写法无绝对值） | 逐步带符号的和在步间平均时会相互抵消；取绝对值是标准一阶 Taylor 准则 |
| 统计量在 `optimizer.step()` 之前读取 | 使 g 与 W 属于同一步 |
| ResNet：每个 stage 的残差流一组（加法节点耦合）+ 每个 block 的内部宽度各一组，共 12 个可剪组 | 论文要求残差两支在加法节点耦合；内部宽度不受此约束，独立剪枝粒度更细。stem 与 fc 输出不剪（"首层与分类层不收缩"） |
| VGG：投影层两个 4096 隐层也作为可剪层（`--no_prune_fc_hidden` 关闭） | 属于"其余各层"；它占 VGG 参数的一半以上，且对 CIFAR 高度冗余。原实现不剪它们 |
| 所有层都在预算档位上按前缀初始化 | 初始结构与 HeteroFL 的 L/M/S 完全相同，初始参数量可直接对齐 |
| 全部层已到逐层下限时也标记停止 | 此后不可能再有可行收缩，停止与否行为完全相同，只省去验证评估 |
| 激活轮记录 teacher / 初始化 student / 训练后 student 的验证损失与准确率 | 为 R2-W1"激活前后跳变"准备实验数据 |
| **默认 ε=0.05、η=0.5**（λ_max=0.2，δ_min=0.03，φ=0.25，k_min=4，ρ_min=0.10） | 见下 |

**ε 与 η 的取值依据。** 80/10/10 切分下每个客户端验证集约 45–50 个样本，一个样本约 2.2 个百分点。ε=0.02 低于这个分辨率，等价于 ε=0；同时"历史最好值"是若干次带噪评估的最大值，系统性偏高。模拟（真实准确率恒定 80%、二项噪声、n=45）：ε=0.02 时第 2–7 个观测点的门控通过率仅为 0.55→0.19，即性能并未下降也会被大量卡住；ε=0.05 时为 0.66→0.33。趋势比值的噪声约 ±5–7%，η=1 会使 λ 每次抖动 ±0.05–0.07（与 λ≈0.1 同量级），因此取 η=0.5。

## 5. 发现的设计问题：训练进展与收缩效应混淆（需要你决定）

门控与趋势都把当前验证准确率和**更早、训练更少**的检查点比较。联邦训练曲线仍在上升时，训练进展会被读成"收缩没有造成损失"：门控总是放行，力度被推高。用实际的 `CapacityController`、VGG16 参数计数、n=45 二项噪声做的模拟（单元格为最终 ρ/ρ0 / 真实准确率变化，sens 为参数减半时的真实损失）：

| 控制器 | 上升期, 无损 | 上升期, sens=0.06 | 平台期, 无损 | 平台期, sens=0.06 |
|---|---|---|---|---|
| 固定 λ=0.1（无门控、无趋势） | 0.43 / +0.0 | 0.43 / −7.9 | 0.43 / +0.0 | 0.43 / −7.9 |
| 文档公式（ε=.05, η=.5） | 0.32 / +0.0 | 0.40 / **−9.8** | 0.45 / +0.0 | 0.51 / −6.2 |
| 非对称（η=1, η_up=0.1） | 0.44 / +0.0 | 0.48 / −6.9 | 0.52 / +0.0 | 0.56 / −4.8 |

结论：文档公式在上升期比固定计划压得更狠、损失更大；只有在平台期才体现出"按证据少压"的优势。这是模拟，准确率模型是假设的，但方向性结论来自公式结构本身。

备选修正 `--preset new_asym`：比值下降时用 η，上升时只用 η_up（上升可能来自训练进展而非收缩，与文档"趋势信号不是收缩的因果效应"一致）。它在四种情形下都不比文档公式差。**若采用，需要修改 `eq:cap_intensity` 并新增一个超参数 η_up**，所以默认仍是文档公式，预实验里并列比较后再定。

## 6. 公平性与需要你决策的事项

1. **baseline 是否重跑。** 新流水线下所有方法共用 80% 训练子集，且本地测试集评估去掉了增强。旧 baseline 的 Local 数字是在"90% 训练 + 带增强评估"下得到的，与新 ESPFL 不可比。建议 baseline 用新 `main.py` 重跑（baseline 代码本身不动）。若不重跑，至少要用 `FIX_EVAL_TRANSFORM=False` 复现旧评估方式，并说明 ESPFL 训练数据更少。
2. **优化器。** baseline 代码用 SGD(momentum 0.9, lr 3e-4·0.998^t)，论文写的是 SGD(lr 0.01, momentum 0.5)，旧 ESPFL 用 AdamW。实验设置部分必须按实际代码改写。
3. **档位比例方向。** 论文写弱:中:强 = 4:3:3，代码是 L:M:S = 40%:30%:30%（强档 40%）。二者相反，需确认并统一。
4. **档位分配随机性。** HeteroFL 用未设种子的 `random.shuffle` 分配档位（现在 `main.py` 已设 `random.seed`，可复现但与 ESPFL/FIARSE 的 seed-42 分配不同）。各方法的"哪个客户端在哪一档"不一致，建议统一。
5. **AKI 的继承强度很弱。** 按 Eq.20（分母为模板总通道数），每次收缩 Δπ≈0.05–0.17，γ≈0.83–0.95，KD 权重只有 5–17%。这是论文公式本身的结果；`aki_dpi_norm='current'`（相对当前宽度）可加强继承，但同样会改公式。

## 7. 预实验建议

`scripts/preexp.sh` 运行 5 个臂：`new`（文档公式）、`legacy`（原分段规则，改用验证集）、`new_origcoef`（新控制器 + 原层系数）、`new_asym`（§5 修正）、`no_easa`（固定档位 + SPPA）。

- `no_easa` 应与 HeteroFL 在新流水线下的结果接近（同结构、同聚合语义），先用它确认流水线没有引入差异。
- 比较 Local、Global、Comm、每档最终 ρ，以及 `structure.json` 中各观测点的 `permit/lam/reason` 分布：门控在训练后期的通过率、λ 随时间的轨迹，可以直接验证 §5 的混淆是否在真实数据上出现。
- 确定控制器后，敏感性分析至少覆盖 ε ∈ {0.02, 0.05, 0.08} 与 η ∈ {0.25, 0.5, 1.0}（阶段 4 文档要求）。

## 8. 结果文件（供回复审稿意见使用）

- `*_summary.json`：Local（全部 N 个客户端，Eq.34）与分档 Local、Global（最终/最好）、每参与者每轮平均上行参数（Eq.35）、分档初始/最终 ρ、切换次数分布。
- `*_structure.json`：每个客户端最终的保留通道索引（不同 seed 之间算 IoU → R1-2 / R2-W2 决策稳定性）、每个观测点的完整决策记录、每次激活的 Δπ / Δout / γ 及激活前后验证损失（→ R2-W1）、每轮覆盖率。
- 消融预设：`fixed` / `gate_only` / `trend_only`（两个信号各自的作用）、`no_aki` / `aki_fixed` / `aki_gate_only` / `aki_kd_only`、`zerofill`（w/o SPPA）、`random_comp` / `magnitude_comp`（S/E/D 的作用）、`no_easa`。

## 9. 验证范围

已验证（CPU，单测 + 合成数据端到端）：模板与 `models.py` 键名/形状/参数量一致；切片子网的输出与"全宽模型 + 门控置零被删通道"逐元素一致（VGG 与 ResNet）；两步嵌套切片等于直接切片；SPPA 与填零聚合的算术；控制器各分支（门控、趋势、全局下限二分与停止、逐层下限）；组成决策的嵌套性与 K；切分后本地测试集与旧切分逐样本一致；完整协议在两种架构上跑通。

未验证：真实 CIFAR/FEMNIST 上的精度与收敛（运行环境无 GPU，也无法访问数据集）。默认超参数只基于噪声分析与模拟，必须以预实验结果为准。
