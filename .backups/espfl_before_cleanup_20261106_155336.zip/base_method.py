# base_method.py
from abc import ABC, abstractmethod
import torch
import torch.nn as nn
from typing import Dict, List


class BaseMethod(ABC):

    @abstractmethod
    def distribute(self, selected_clients: list):
        """将全局模型分发到选中的客户端"""
        ...

    @abstractmethod
    def local_update(
        self,
        selected_clients: list,
        train_loaders: dict,
        test_loaders: dict,
        round_idx: int,
        lr: float,
    ) -> dict:
        """
        客户端本地训练。
        返回格式：
        {
            client_id: {
                'accuracy': float,
                'params': int,
                'compression': float
            },
            ...
        }
        """
        ...

    @abstractmethod
    def aggregate(self, selected_clients: list, train_loaders: dict) -> None:
        """服务器端聚合，结果更新内部 global_model"""
        ...

    @abstractmethod
    def get_global_model(self):
        """返回当前全局模型（CPU上）"""
        ...

    @abstractmethod
    def set_global_model(self, model) -> None:
        """更新全局模型"""
        ...

    def post_round_hook(
        self,
        selected_clients: list,
        train_loaders: dict,
        test_loaders: dict,
        round_idx: int,
    ) -> None:
        """每轮聚合后的可选操作，默认空实现，子类按需重写"""
        pass

    def evaluate_local_clients(
        self,
        client_ids: List[int],
        test_loaders: dict,
        device: torch.device,
    ) -> Dict[int, float]:
        """
        在指定客户端的本地测试集上评估其当前个性化模型的准确率。

        默认实现：直接调用各子类已有的 _load_client_model / _eval_with_mask
        等方法。子类若有特殊评估逻辑（如带 mask 推理）可重写此方法。

        约定：
            - 对于 OurMethod：加载 client_states 中的模型（含剪枝结构）在 test_loader 上评估
            - 对于 DittoMethod：加载 client_personal_states 中的个性化模型评估
            - 对于 FIARSEMethod：加载 client_states 并用 capacity mask 推理

        返回：
            {client_id: accuracy_float}，accuracy 为百分比形式（如 83.2）
        """
        from train_utils import test_model

        results: Dict[int, float] = {}
        for cid in client_ids:
            try:
                model = None

                # ── Ditto：优先用个性化模型 ──────────────────────────────
                if hasattr(self, 'client_personal_states'):
                    state = self.client_personal_states.get(cid)
                    if state is not None:
                        model = self._build_model_from_state(state, device)

                # ── OurMethod / FIARSE：用客户端当前模型 ─────────────────
                if model is None and hasattr(self, 'client_states'):
                    state = self.client_states.get(cid)
                    if state is not None:
                        if hasattr(self, '_load_client_model'):
                            model = self._load_client_model(cid, to_device=device)
                        elif hasattr(self, '_load_state_as_model'):
                            model = self._load_state_as_model(state).to(device)

                # ── 兜底：用全局模型评估（客户端从未参与训练时）────────────
                if model is None:
                    model = self.get_global_model().to(device)

                # ── FIARSE 带 mask 推理 ───────────────────────────────────
                if hasattr(self, '_eval_with_mask') and hasattr(self, 'client_capacities'):
                    acc = self._eval_with_mask(model, test_loaders[cid], self.client_capacities[cid])
                else:
                    acc = test_model(model, test_loaders[cid], device)

                results[cid] = acc
                model = model.cpu()
                del model

            except Exception as e:
                print(f"  [EvalLocal] Client {cid} eval failed: {e}")
                results[cid] = 0.0

        torch.cuda.empty_cache()
        return results